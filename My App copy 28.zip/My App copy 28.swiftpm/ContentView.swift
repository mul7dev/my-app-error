import SwiftUI
import Combine

// Firebase Configuration
let firebaseAPIKey = "AIzaSyCvdFfQrS-LMULbhbrca6XtMZOUsyX4Rug"
let firebaseDatabaseURL = "https://minichatswift-default-rtdb.firebaseio.com"

// Models
struct ChatMessage: Identifiable, Codable {
    var id = UUID().uuidString
    let sender: String
    let text: String
    let timestamp: Date
    
    enum CodingKeys: String, CodingKey {
        case sender
        case text
        case timestamp
    }
    
    init(sender: String, text: String, timestamp: Date) {
        self.sender = sender
        self.text = text
        self.timestamp = timestamp
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        sender = try container.decode(String.self, forKey: .sender)
        text = try container.decode(String.self, forKey: .text)
        let timestampDouble = try container.decode(Double.self, forKey: .timestamp)
        timestamp = Date(timeIntervalSince1970: timestampDouble)
    }
}

struct User: Codable {
    let idToken: String
    let localId: String
}

// Error Handling
enum ChatServiceError: Error {
    case custom(String)
}

// Firebase Error Mapping
func mapFirebaseError(_ errorMessage: String) -> String {
    switch errorMessage {
    case "EMAIL_EXISTS":
        return "This email is already registered. Please use a different email or sign in."
    case "INVALID_PASSWORD":
        return "The password you entered is incorrect. Please try again."
    case "EMAIL_NOT_FOUND":
        return "No account found with this email. Please check the email address or sign up."
    case "USER_DISABLED":
        return "Your account has been disabled. Please contact support for assistance."
    case "OPERATION_NOT_ALLOWED":
        return "Sign-in with this method is not enabled. Please contact support."
    case "TOO_MANY_ATTEMPTS_TRY_LATER":
        return "Too many failed attempts. Please try again later."
    default:
        return "An unknown error occurred: \(errorMessage). Please try again."
    }
}

// ChatService
class ChatService: ObservableObject {
    @Published var publicMessages: [ChatMessage] = []
    @Published var privateMessages: [String:[ChatMessage]] = [:]
    var idToken: String?
    var uid: String?
    
    private var publicTimer: Timer?
    private var gongTimer: Timer?
    
    // Real-Time Updates
    func startFetchingPublicMessages() {
        fetchPublicMessages()
        publicTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            self.fetchPublicMessages()
        }
    }
    
    func startFetchingPrivateMessages() {
        fetchPublicMessages()
        gongTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            self.fetchPublicMessages()
        }
    }
    
    func stopFetchingPublicMessages() {
        publicTimer?.invalidate()
        publicTimer = nil
    }
    
    func stopFetchingPrivateMessages() {
        gongTimer?.invalidate()
        gongTimer = nil
    }
    
    // Fetch Messages
    func fetchPublicMessages() {
        guard let url = URL(string: "\(firebaseDatabaseURL)/publicchat.json") else { return }
        
        URLSession.shared.dataTask(with: url) { data, _, error in
            if let error = error { print("Error fetching messages: \(error.localizedDescription)"); return }
            guard let data = data else { print("No data received."); return }
            
            do {
                let messagesData = try JSONDecoder().decode([String: ChatMessage?].self, from: data)
                let validMessages = messagesData.compactMap { $0.value }
                DispatchQueue.main.async {
                    self.publicMessages = validMessages.sorted(by: { $0.timestamp < $1.timestamp })
                }
            } catch {
                print("Error decoding messages: \(error.localizedDescription)")
            }
        }.resume()
    }
    
    func fetchPrivateMessages(uid: String) {
        guard let url = URL(string: "\(firebaseDatabaseURL)/conversations/uid.json") else { return }
        
        URLSession.shared.dataTask(with: url) { data, _, error in
            if let error = error { print("Error fetching messages: \(error.localizedDescription)"); return }
            guard let data = data else { print("No data received."); return }
            
            do {
                let messagesData = try JSONDecoder().decode([String: ChatMessage?].self, from: data)
                let validMessages = messagesData.compactMap { $0.value }
                DispatchQueue.main.async {
                    self.publicMessages = validMessages.sorted(by: { $0.timestamp < $1.timestamp })
                }
            } catch {
                print("Error decoding messages: \(error.localizedDescription)")
            }
        }.resume()
    }
    
    func sendMessage(sender: String, text: String) {
        var sender = sender
        print("Sender is \(sender)")
        if sender == "" {
            sender = "Unknown"
        }
        let message = ChatMessage(sender: sender, text: text, timestamp: Date())
        guard let url = URL(string: "\(firebaseDatabaseURL)/publicchat/\(message.id).json") else { return }
        
        var request = URLRequest(url: url)
        request.httpMethod = "PUT"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try? JSONEncoder().encode(message)
        
        URLSession.shared.dataTask(with: request) { _, _, error in
            if let error = error { print("Error sending message: \(error.localizedDescription)") }
        }.resume()
    }
    // Send Message
    func sendPrivateMessage(sender: String, text: String, chat uid: String) {
        let message = ChatMessage(sender: sender, text: text, timestamp: Date())
        guard let url = URL(string: "\(firebaseDatabaseURL)/conversations/\(uid)/\(message.id).json") else { return }
        
        var request = URLRequest(url: url)
        request.httpMethod = "PUT"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try? JSONEncoder().encode(message)
        
        URLSession.shared.dataTask(with: request) { _, _, error in
            if let error = error { print("Error sending message: \(error.localizedDescription)") }
        }.resume()
    }
    
    // Save Data
    func saveData(uid: String, path: String, data: [String: Any], completion: @escaping (Result<Void, ChatServiceError>) -> Void) {
        guard let url = URL(string: "\(firebaseDatabaseURL)/\(uid)/\(path).json") else {
            completion(.failure(.custom("Invalid request. Please try again later.")))
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "PUT"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: data)
        } catch {
            completion(.failure(.custom("Failed to encode data. Please try again.")))
            return
        }
        
        URLSession.shared.dataTask(with: request) { _, _, error in
            if let error = error {
                completion(.failure(.custom("Network error: \(error.localizedDescription). Please check your connection.")))
                return
            }
            completion(.success(()))
        }.resume()
    }
    
    // Read Data
    func readData(uid: String, path: String, completion: @escaping (Result<[String: Any], ChatServiceError>) -> Void) {
        guard let url = URL(string: "\(firebaseDatabaseURL)/\(uid)/\(path).json") else {
            completion(.failure(.custom("Invalid request. Please try again later.")))
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, _, error in
            if let error = error {
                completion(.failure(.custom("Network error: \(error.localizedDescription). Please check your connection.")))
                return
            }
            
            guard let data = data else {
                completion(.failure(.custom("No response from server. Please try again later.")))
                return
            }
            
            do {
                let result = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
                completion(.success(result ?? [:]))
            } catch {
                completion(.failure(.custom("Failed to decode data. Please try again.")))
            }
        }.resume()
    }
    
    // Sign-Up
    func signUp(email: String, password: String, completion: @escaping (Result<User, ChatServiceError>) -> Void) {
        guard let url = URL(string: "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=\(firebaseAPIKey)") else {
            completion(.failure(.custom("Invalid request. Please try again later.")))
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let payload: [String: Any] = ["email": email, "password": password, "returnSecureToken": true]
        
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: payload)
        } catch {
            completion(.failure(.custom("Failed to encode sign-up data. Please try again.")))
            return
        }
        
        URLSession.shared.dataTask(with: request) { data, _, error in
            if let error = error {
                completion(.failure(.custom("Network error: \(error.localizedDescription). Please check your connection.")))
                return
            }
            
            guard let data = data else {
                completion(.failure(.custom("No response from server. Please try again later.")))
                return
            }
            
            do {
                let user = try JSONDecoder().decode(User.self, from: data)
                DispatchQueue.main.async {
                    self.idToken = user.idToken
                    self.uid = user.localId
                    completion(.success(user))
                }
            } catch {
                if let firebaseError = try? JSONDecoder().decode([String: String].self, from: data) {
                    let errorMessage = firebaseError["error"] ?? "An unknown error occurred."
                    completion(.failure(.custom(mapFirebaseError(errorMessage))))
                } else {
                    completion(.failure(.custom("An unknown error occurred. Please try again.")))
                }
            }
        }.resume()
    }
    
    // Sign-In
    func signIn(email: String, password: String, completion: @escaping (Result<User, ChatServiceError>) -> Void) {
        guard let url = URL(string: "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=\(firebaseAPIKey)") else {
            completion(.failure(.custom("Invalid request. Please try again later.")))
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let payload: [String: Any] = ["email": email, "password": password, "returnSecureToken": true]
        
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: payload)
        } catch {
            completion(.failure(.custom("Failed to encode sign-in data. Please try again.")))
            return
        }
        
        URLSession.shared.dataTask(with: request) { data, _, error in
            if let error = error {
                completion(.failure(.custom("Network error: \(error.localizedDescription). Please check your connection.")))
                return
            }
            
            guard let data = data else {
                completion(.failure(.custom("No response from server. Please try again later.")))
                return
            }
            
            do {
                let user = try JSONDecoder().decode(User.self, from: data)
                DispatchQueue.main.async {
                    self.idToken = user.idToken
                    self.uid = user.localId
                    completion(.success(user))
                }
            } catch {
                if let firebaseError = try? JSONDecoder().decode([String: String].self, from: data) {
                    let errorMessage = firebaseError["error"] ?? "An unknown error occurred."
                    completion(.failure(.custom(mapFirebaseError(errorMessage))))
                } else {
                    completion(.failure(.custom("An unknown error occurred. Please try again.")))
                }
            }
        }.resume()
    }
    
    // Reset Password
    func resetPassword(email: String, completion: @escaping (Result<Void, ChatServiceError>) -> Void) {
        guard let url = URL(string: "https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key=\(firebaseAPIKey)") else {
            completion(.failure(.custom("Invalid request. Please try again later.")))
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let payload: [String: Any] = ["requestType": "PASSWORD_RESET", "email": email]
        
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: payload)
        } catch {
            completion(.failure(.custom("Failed to encode reset password data. Please try again.")))
            return
        }
        
        URLSession.shared.dataTask(with: request) { data, _, error in
            if let error = error {
                completion(.failure(.custom("Network error: \(error.localizedDescription). Please check your connection.")))
                return
            }
            
            completion(.success(()))
        }.resume()
    }
}

// Views
struct LoginView: View {
    @ObservedObject var chatService = ChatService()
    @State private var email = ""
    @State private var password = ""
    @State private var isSignedIn = false
    @State private var errorMessage: String?
    @State private var SSO: Bool = UserDefaults.standard.bool(forKey: "SSO")
    
    var body: some View {
        VStack {
            if isSignedIn {
                ChatView(chatService: chatService, email: email, isSignedIn: $isSignedIn, SSO: $SSO)
            } else {
                VStack {
                    TextField("Email", text: $email)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .autocapitalization(.none)
                        .padding()
                    
                    SecureField("Password", text: $password)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding()
                    
                    if let errorMessage = errorMessage {
                        Text(errorMessage)
                            .foregroundColor(.red)
                            .padding()
                    }
                    
                    Button("Sign In") {
                        chatService.signIn(email: email, password: password) { result in
                            switch result {
                            case .success:
                                isSignedIn = true
                                UserDefaults.standard.setValue(email, forKey: "email")
                                UserDefaults.standard.setValue(password, forKey: "password")
                            case .failure(let error):
                                if case let ChatServiceError.custom(message) = error {
                                    errorMessage = message
                                }
                            }
                        }
                    }
                    .padding()
                    
                    Button("Sign Up") {
                        chatService.signUp(email: email, password: password) { result in
                            switch result {
                            case .success:
                                isSignedIn = true
                                UserDefaults.standard.setValue(email, forKey: "email")
                                UserDefaults.standard.setValue(password, forKey: "password")
                            case .failure(let error):
                                if case let ChatServiceError.custom(message) = error {
                                    errorMessage = message
                                }
                            }
                        }
                    }
                    .padding()
                }
            }
        }
        .onAppear {
            if SSO {
                let savedEmail = UserDefaults.standard.string(forKey: "email") ?? ""
                let savedPassword = UserDefaults.standard.string(forKey: "password") ?? ""
                chatService.signIn(email: savedEmail, password: savedPassword) { result in
                    switch result {
                    case .success:
                        isSignedIn = true
                    case .failure(let error):
                        print("Error signing in using SSO: \(error)")
                    }
                }
            }
        }
    }
}

struct ChatView: View {
    @ObservedObject var chatService: ChatService
    let email: String
    @Binding var isSignedIn: Bool
    @Binding var SSO: Bool
    
    @State private var selectedView: String? = nil
    
    var body: some View {
        NavigationSplitView {
            List(selection: $selectedView) {
                Section {
                    NavigationLink("Public Chat", value: "PublicChat")
                }
                Section {
                    
                }
                NavigationLink("Settings", value: "Settings")
            }
            .navigationTitle("Tortuchat")
        } detail: {
            if let selectedView = selectedView {
                switch selectedView {
                case "PublicChat":
                    PublicChatView(chatService: chatService, email: email, isSignedIn: $isSignedIn, SSO: $SSO)
                case "Settings":
                    SettingsView(email: email, chatService: chatService, isSignedIn: $isSignedIn, SSO: $SSO)
                default:
                    Text("Select an option from the menu")
                }
            } else {
                PublicChatView(chatService: chatService, email: email, isSignedIn: $isSignedIn, SSO: $SSO)
            }
        }
    }
}

struct PrivateChatView: View {
    @ObservedObject var chatService: ChatService
    let email: String
    @Binding var isSignedIn: Bool
    @Binding var SSO: Bool
    @State private var messageText = ""
    let chatUID: String
    
    var body: some View {
        NavigationStack {
            VStack {
                List(chatService.privateMessages[chatUID]!) { message in
                    VStack(alignment: .leading) {
                        Text("\(message.sender):")
                            .font(.caption)
                            .foregroundColor(.gray)
                        Text(message.text)
                            .padding()
                            .background(Color.gray.opacity(0.2))
                            .cornerRadius(8)
                    }
                }
                .onAppear {
                    chatService.startFetchingPrivateMessages()
                }
                .onDisappear {
                    chatService.stopFetchingPrivateMessages()
                }
                
                HStack {
                    TextField("Enter message", text: $messageText)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                    Button("Send") {
                        if !messageText.isEmpty {
                            chatService.sendMessage(sender: email, text: messageText)
                            messageText = ""
                        }
                    }
                }
                .padding()
            }
        }
    }
}

struct PublicChatView: View {
    @ObservedObject var chatService: ChatService
    let email: String
    @Binding var isSignedIn: Bool
    @Binding var SSO: Bool
    @State private var messageText = ""
    
    var body: some View {
        NavigationStack {
            VStack {
                List(chatService.publicMessages) { message in
                    VStack(alignment: .leading) {
                        Text("\(message.sender):")
                            .font(.caption)
                            .foregroundColor(.gray)
                        Text(message.text)
                            .padding()
                            .background(Color.gray.opacity(0.2))
                            .cornerRadius(8)
                    }
                }
                .onAppear {
                    chatService.startFetchingPublicMessages()
                }
                .onDisappear {
                    chatService.stopFetchingPublicMessages()
                }
                
                HStack {
                    TextField("Enter message", text: $messageText)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                    Button("Send") {
                        if !messageText.isEmpty {
                            chatService.sendMessage(sender: email, text: messageText)
                            messageText = ""
                        }
                    }
                }
                .padding()
            }
        }
        .navigationTitle("Public Chat")
    }
}

struct SettingsView: View {
    let email: String
    @ObservedObject var chatService: ChatService
    @Binding var isSignedIn: Bool
    @Binding var SSO: Bool
    @State private var successMessage: String?
    @State private var errorMessage: String?
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        VStack {
            if let successMessage = successMessage {
                Text(successMessage)
                    .foregroundColor(.green)
                    .padding()
            }
            
            if let errorMessage = errorMessage {
                Text(errorMessage)
                    .foregroundColor(.red)
                    .padding()
            }
            
            Button("Reset Password") {
                chatService.resetPassword(email: email) { result in
                    switch result {
                    case .success:
                        successMessage = "Password reset email sent successfully."
                    case .failure(let error):
                        if case let ChatServiceError.custom(message) = error {
                            errorMessage = message
                        }
                    }
                }
            }
            .padding()
            
            Button("Log Out") {
                chatService.stopFetchingPublicMessages()
                chatService.stopFetchingPrivateMessages()
                isSignedIn = false
                UserDefaults.standard.removeObject(forKey: "email")
                UserDefaults.standard.removeObject(forKey: "password")
                UserDefaults.standard.setValue(false, forKey: "SSO")
                presentationMode.wrappedValue.dismiss()
            }
            .padding()
            
            Toggle(isOn: $SSO) {
                Text("SSO")
            }
            .padding()
            .onChange(of: SSO) { newVal in
                UserDefaults.standard.setValue(newVal, forKey: "SSO")
            }
        }
        .padding()
    }
}

// App Entry Point
@main
struct PublicChatApp: App {
    var body: some Scene {
        WindowGroup {
            LoginView(chatService: ChatService())
        }
    }
}
